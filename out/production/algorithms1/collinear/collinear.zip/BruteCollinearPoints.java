import java.util.ArrayList;
import java.util.Arrays;

public class BruteCollinearPoints {
    private LineSegment[] segments;

    public BruteCollinearPoints(Point[] points) {   // finds all line segments containing 4 points
        if (points == null) throw new IllegalArgumentException();
        Arrays.sort(points);
        isInvalid(points);
        ArrayList<LineSegment> segmentsInPlace = new ArrayList<>();
        for (int p = 0; p < points.length - 3; p++)
            for (int q = p + 1; q < points.length - 2; q++)
                for (int r = q + 1; r < points.length - 1; r++)
                    for (int s = r + 1; s < points.length; s++)
                        if (points[p].slopeTo(points[q]) == points[r].slopeTo(points[s]) &&
                                points[p].slopeTo(points[q]) == points[q].slopeTo(points[r])) {
                            LineSegment newSegment = new LineSegment(points[p], points[s]);
                            if (!isThere(segmentsInPlace, newSegment))
                                segmentsInPlace.add(newSegment);
                        }
        this.segments = segmentsInPlace.toArray(new LineSegment[segmentsInPlace.size()]);
    }

    public int numberOfSegments() { // the number of line segments
        return this.segments.length;
    }

    public LineSegment[] segments() { // the line segments
        return this.segments;
    }

    private static boolean isThere(ArrayList<LineSegment> data, LineSegment toAdd) {
        String stringData = toAdd.toString();
        for (LineSegment line : data)
            if (line.toString().compareTo(stringData) == 0)
                return true;
        return false;
    }

    private static void isInvalid(Point[] points) {
        if (points[0] == null) throw new IllegalArgumentException();
        for (int i = 1; i < points.length; i++)
            if (points[i] == points[i - 1] || points[i] == null) throw new IllegalArgumentException();
    }
}
